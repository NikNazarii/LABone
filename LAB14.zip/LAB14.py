
# 1. Написати програму для обробки контенту web-сторінки (приклад 14.1).

# import requests
# from bs4 import BeautifulSoup
#
# class HabrPythonNews:
#     def __init__(self):
#         self.url = 'https://www.python.org/'
#         self.html = self.get_html()
#
#     def get_html(self):
#         try:
#             result = requests.get(self.url)
#             result.raise_for_status()
#             return result.text
#         except (requests.RequestException, ValueError):
#             print('Помилка доступу до сервера')
#             return False
#
#     def get_python_news(self):
#         if not self.html:
#             return []
#         soup = BeautifulSoup(self.html, 'html.parser')
#         news_list = soup.find_all('h3', class_='post__title')
#         return [news.get_text(strip=True) for news in news_list]
#
# if __name__ == "__main__":
#     news_collector = HabrPythonNews()
#     news_titles = news_collector.get_python_news()
#     for title in news_titles:
#         print(title)
#

# 2. Написати програму для роботи з файлами web-сайту (приклад 14.2).

# import requests
#
# def download_image(url, file_name):
#     try:
#         image = requests.get(url)
#         image.raise_for_status()
#         with open(file_name, 'wb') as f:
#             f.write(image.content)
#         print(f"Зображення збережено як '{file_name}'")
#     except (requests.RequestException, IOError) as e:
#         print(f"Помилка при завантаженні зображення: {e}")
#
# if __name__ == "__main__":
#     image_url = "https://www.python.org/static/img/python-logo.png"
#     file_name = "new_image.png"
#     download_image(image_url, file_name)



# Варіант 16
# 1. Написати програму, яка підраховує і записує у файл JSON частоту, з
# якою зустрічаються на веб-сторінці літери українського алфавіту, що
# позначають приголосні звуки. URL-адресу веб-сторінки вводить користувач.


# import requests
# from bs4 import BeautifulSoup
# import json
# from collections import Counter
#
# UKRAINIAN_CONSONANTS = set("бвгґджзйклмнпрстфхцчшщ")
#
# def count_consonants(text):
#     consonant_counts = Counter([char for char in text.lower() if char in UKRAINIAN_CONSONANTS])
#     return dict(consonant_counts)
#
# def save_consonants_frequency(url, output_file):
#     try:
#         response = requests.get(url)
#         response.raise_for_status()
#
#         soup = BeautifulSoup(response.text, 'html.parser')
#         page_text = soup.get_text()
#
#         consonant_frequency = count_consonants(page_text)
#
#         with open(output_file, 'w', encoding='utf-8') as f:
#             json.dump(consonant_frequency, f, ensure_ascii=False, indent=4)
#         print(f"Частоти приголосних літер збережено у файлі '{output_file}'")
#
#     except (requests.RequestException, IOError) as e:
#         print(f"Помилка при доступі до веб-сторінки або записі у файл: {e}")
#
# if __name__ == "__main__":
#     url = input("Введіть URL веб-сторінки: ")
#     output_file = "consonant_frequency.json"
#     save_consonants_frequency(url, output_file)




# 2. Користувач задає адресу веб-сторінки. Програма повинна записати у
# файл image.txt імена всіх файлів із зображеннями, посилання на які є на вебсторінці (тег <IMG>).

# import requests
# from bs4 import BeautifulSoup
# import os
#
# def extract_image_filenames(url, output_file):
#     try:
#         response = requests.get(url)
#         response.raise_for_status()
#
#         soup = BeautifulSoup(response.text, 'html.parser')
#         image_tags = soup.find_all("img")
#
#         image_filenames = []
#         for img_tag in image_tags:
#             src = img_tag.get("src")
#             if src:
#                 filename = os.path.basename(src)
#                 image_filenames.append(filename)
#
#         with open(output_file, 'w', encoding='utf-8') as f:
#             for filename in image_filenames:
#                 f.write(filename + '\n')
#         print(f"Імена файлів зображень збережено у файлі '{output_file}'")
#
#     except (requests.RequestException, IOError) as e:
#         print(f"Помилка при доступі до веб-сторінки або записі у файл: {e}")
#
# if __name__ == "__main__":
#     url = input("Введіть URL веб-сторінки: ")
#     output_file = "image.txt"
#     extract_image_filenames(url, output_file)
