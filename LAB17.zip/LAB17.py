

""" 1. Написати програму, яка використовує DataFrame (приклад 17.1). """

# import pandas as pd
#
# with open("trade.txt", 'r') as f:
#     list1 = []
#     list2 = []
#
#     for line in f:
#         x = line.index(' ')
#         s1 = line[:x]
#         s2 = line[x + 1:].strip()
#         list1.append(s1)
#         list2.append(s2)
#
# df = pd.DataFrame({'Firm': list1, 'Employees': list2})
#
# print(df)

""" 2. Написати програму, яка використовує Series (приклад 17.2). """

# import pandas as pd
#
#
# with open("trade.txt", 'r') as f:
#     list1 = []
#     list2 = []
#
#     for line in f:
#         x = line.index(' ')
#         s1 = line[:x]
#         s2 = line[x + 1:].strip()
#         list1.append(s1)
#         list2.append(int(s2))
#
# series = pd.Series(list2, index=list1)
#
# print(series)


'''
Варіант 16

1. Файл time.csv містить дані про час подолання спортсменамилегкоатлетами дистанцій 100 м, 500 м, 1 км, 3 км. Написати програму, яка: 1)
зчитає ці дані в масив DataFrame; 2) створить на основі даного масиву другий
масив, у який будуть занесені швидкості, з якими рухався кожен із спортсменів
на кожній ділянці; 3) запише створений масив у файл speed.csv. '''

# import pandas as pd
#
# time_df = pd.read_csv("time.csv")
#
# distances = {'100m': 100, '500m': 500, '1km': 1000, '3km': 3000}
#
# speed_data = {}
#
# for distance, meters in distances.items():
#     speed_data[distance] = meters / time_df[distance]
#
# speed_df = pd.DataFrame(speed_data)
# speed_df.insert(0, 'Name', time_df['Name'])
#
# speed_df.to_csv("speed.csv", index=False)
#
# print("Дані швидкості збережено у файл speed.csv")

"""2. Файл cifra.txt містить цілі числа, записані у стовпчик. Написати
програму, яка: 1) запише всі числа в масив Series; 2) запише в новий масив
найбільші дільники чисел, які входять у початковий масив; 3) збереже новий
масив у файл masiv.json."""

# import pandas as pd
# import json
#
# def find_largest_divisor(n):
#     for i in range(n // 2, 0, -1):
#         if n % i == 0:
#             return i
#     return 1
#
# with open("cifra.txt", 'r') as f:
#     numbers = [int(line.strip()) for line in f]
#
# series = pd.Series(numbers)
#
# largest_divisors = series.apply(find_largest_divisor)
#
# largest_divisors.to_json("masiv.json", orient='values', indent=4)
#
# print("Новий масив збережено у файл masiv.json")
