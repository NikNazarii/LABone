
# 1. Написати програму з використанням класу (приклад 13.1).

# class Apple:
#     __d = 0.0
#     __m = 0.0
#     __color = 'none'
#
#     def __init__(self, d=0.0, m=0.0, color='none'):
#         self.__d = float(d)
#         self.__m = float(m)
#         self.__color = str(color)
#
#     def set_d(self, d):
#         self.__d = float(d)
#
#     def set_m(self, m):
#         self.__m = float(m)
#
#     def set_color(self, color):
#         self.__color = str(color)
#
#     def get_d(self):
#         return self.__d
#
#     def get_m(self):
#         return self.__m
#
#     def get_color(self):
#         return self.__color
#
#
# apple1 = Apple(3, 7, 'білий')
#
# print("Початкові значення:")
# print("Колір:", apple1.get_color())
# print("Діаметр:", apple1.get_d())
# print("Маса:", apple1.get_m())
#
# apple1.set_d(12.2)
# apple1.set_m(10.5)
# apple1.set_color('жовтий')
#
# print("\nЗмінені значення:")
# print("Колір:", apple1.get_color())
# print("Діаметр:", apple1.get_d())
# print("Маса:", apple1.get_m())


# from fruits import Fruit
#
# fruit1 = Fruit("Яблуко", 150, "червоний")
#
# print("Початкові значення:")
# print("Вид фрукта:", fruit1.get_kind())
# print("Маса:", fruit1.get_masa())
# print("Колір:", fruit1.get_color())
#
# fruit1.set_color("зелений")
# fruit1.set_masa(200)
# fruit1.set_kind("Груша")
#
# print("\nЗмінені значення:")
# print("Вид фрукта:", fruit1.get_kind())
# print("Маса:", fruit1.get_masa())
# print("Колір:", fruit1.get_color())
#



# Варіант 16
# 1. Клас DIGIT являє собою натуральне число і має такі властивості:
# значення, парність (булевий тип), а також методи: конструктор класу, дільники
# (список дільників числа). Написати програму, яка хвиводитиме повідомлення
# про те, чи є число простим.


# class DIGIT:
#     def __init__(self, value):
#         if value < 1:
#             raise ValueError("Число має бути натуральним (ціле та більше 0).")
#
#         self.value = value
#         self.is_even = (value % 2 == 0)
#
#     def divisors(self):
#         divisors_list = [i for i in range(1, self.value + 1) if self.value % i == 0]
#         return divisors_list
#
#     def is_prime(self):
#         if self.value < 2:
#             return False  # 1 не є простим числом
#         for i in range(2, int(self.value ** 0.5) + 1):
#             if self.value % i == 0:
#                 return False
#         return True
#
#
# number = DIGIT(17)
#
# print("Значення:", number.value)
# print("Парність:", "парне" if number.is_even else "непарне")
#
# print("Дільники числа:", number.divisors())
#
# if number.is_prime():
#     print("Число є простим.")
# else:
#     print("Число не є простим.")

# 2. Створити клас JOURNAL (журнал) і записати його в окремому модулі.
# Властивості класу JOURNAL: Name, Publisher, Country, Owner, Papers (список
# статей), Number, Year. Написати для класу JOURNAL такі методи: конструктор
# класу, AddPaper (додає статтю), RemovePaper (видаляє статтю зі списку),
# DisplayProperties (виводить всі властивості, крім списку статей), DisplayPapers
# (виводить список статей). В основній програмі створити 2-3 екземпляри класу
# JOURNAL, дописати в кожен номер журналу по 2-3 статті, вивести зміст
# кожного номера на екран.


from journal import JOURNAL

journal1 = JOURNAL("Science Weekly", "Future Press", "USA", "John Doe", 1, 2023)
journal2 = JOURNAL("Tech Innovations", "Global Media", "UK", "Alice Smith", 2, 2023)
journal3 = JOURNAL("Health Today", "Health Media", "Canada", "Mike Johnson", 3, 2023)

journal1.add_paper("The Future of AI")
journal1.add_paper("Climate Change Impacts")
journal1.add_paper("Advances in Quantum Computing")

journal2.add_paper("5G and the Internet of Things")
journal2.add_paper("Cybersecurity Challenges")
journal2.add_paper("Blockchain Beyond Cryptocurrency")

journal3.add_paper("The Benefits of a Balanced Diet")
journal3.add_paper("Mental Health Awareness")
journal3.add_paper("Exercise for a Longer Life")

print("Журнал 1:")
journal1.display_properties()
journal1.display_papers()
print("\n")

print("Журнал 2:")
journal2.display_properties()
journal2.display_papers()
print("\n")

print("Журнал 3:")
journal3.display_properties()
journal3.display_papers()
