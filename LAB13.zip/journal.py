
class JOURNAL:
    def __init__(self, name, publisher, country, owner, number, year):
        self.name = name
        self.publisher = publisher
        self.country = country
        self.owner = owner
        self.papers = []
        self.number = number
        self.year = year

    def add_paper(self, paper_title):
        self.papers.append(paper_title)

    def remove_paper(self, paper_title):
        if paper_title in self.papers:
            self.papers.remove(paper_title)
        else:
            print(f"Стаття '{paper_title}' не знайдена в журналі.")

    def display_properties(self):
        print(f"Назва журналу: {self.name}")
        print(f"Видавництво: {self.publisher}")
        print(f"Країна: {self.country}")
        print(f"Власник: {self.owner}")
        print(f"Номер: {self.number}")
        print(f"Рік: {self.year}")

    def display_papers(self):
        if self.papers:
            print("Список статей у журналі:")
            for paper in self.papers:
                print(f"- {paper}")
        else:
            print("Наразі у журналі немає статей.")
