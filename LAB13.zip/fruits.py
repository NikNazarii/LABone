class Fruit:
    def __init__(self, kind="невідомо", m=0.0, color='none'):
        self.__kind = str(kind)
        self.__m = float(m)
        self.__color = str(color)

    def set_kind(self, kind):
        self.__kind = kind

    def set_masa(self, m):
        self.__m = float(m)

    def set_color(self, color):
        self.__color = color

    def get_kind(self):
        return self.__kind

    def get_masa(self):
        return self.__m

    def get_color(self):
        return self.__color
