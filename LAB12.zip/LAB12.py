import math
import random

# 1. Написати функцію, яка не повертає значень (приклад 12.1).
#
# def notBack(a, b):
#     c = math.sqrt(a**2 + b**2)
#     print(f"Гіпотенуза: {c}")
#     area = (a * b) / 2
#     print(f"Площа: {area}")
#
#
# # 2. Написати функцію, яка повертає значення (приклад 12.2).
#
#
#
# def randomMat(rows, cols):
#     matrix = [[random.randint(0, 9) for _ in range(cols)] for _ in range(rows)]
#     return matrix
#
#
#
# # 3. Створити модуль з функціями відповідно до варіанта і підключити
# # модуль до основної програми (приклад 12.3).

# import my_module
#
# # Виклик функції, яка не повертає значення
# a = float(input("Введіть перший катет: "))
# b = float(input("Введіть другий катет: "))
# my_module.calculate_triangle(a, b)
#
# # Виклик функції, яка повертає значення
# matrix = my_module.generate_random_matrix()
# print("Згенерований двовимірний масив випадкових чисел:")
# print(matrix)
#
# # Виклик функції, яка генерує випадковий рядок
# length = int(input("Введіть довжину рядка: "))
# random_string = my_module.generate_random_string(length)
# print("Згенерований рядок випадкових символів:")
# print(random_string)


# Варіант 16
# 1. Список налічує 12 назв міст. Програма повинна: 1) видалити з списку всі
# повтори і вивести список на екран; 2) вивести друге і передостаннє слова
# списку. Для цього створити 2 функції.

# def remove_duplicates(cities):
#     unique_cities = list(set(cities))
#     return unique_cities
#
# def get_second_and_penultimate(cities):
#     if len(cities) < 2:
#         return None, None
#     return cities[1], cities[-2]
#
#
# cities = ["Київ", "Львів", "Харків", "Одеса", "Львів", "Київ", "Харків", "Дніпро", "Запоріжжя", "Одеса", "Харків", "Київ"]
#
# unique_cities = remove_duplicates(cities)
# print("Список без повторів:", unique_cities)
#
# second, penultimate = get_second_and_penultimate(unique_cities)
# print("Друге місто:", second)
# print("Передостаннє місто:", penultimate)


# 2. Текст записаний у файл story.txt. Програма повинна видалити з цього
# тексту всі розділові знаки, а результат записати у файл all.txt. Для видалення
# всіх розділових знаків з рядка створити функцію.

# import string
#
# def remove_punctuation(text):
#     """Видаляє всі розділові знаки з тексту."""
#     return text.translate(str.maketrans("", "", string.punctuation))
#
# # Обробка файлів
# with open("story.txt", "r", encoding="utf-8") as file:
#     text = file.read()
#
# cleaned_text = remove_punctuation(text)
#
# with open("all.txt", "w", encoding="utf-8") as file:
#     file.write(cleaned_text)


# 3. Написати модуль з такими функціями: 1) для визначення N-го члена
# арифметичної прогресії; 2) для визначення суми N членів арифметичної
# прогресії. Підключити модуль до основної програми і виконати відповідні
# обчислення.

# import my_module as ap
#
# # Введення параметрів прогресії
# a1 = float(input("Введіть перший член прогресії (a1): "))
# d = float(input("Введіть різницю прогресії (d): "))
# n = int(input("Введіть номер члена (n): "))
#
# # Обчислення n-го члена та суми n членів
# nth = ap.nth_term(a1, d, n)
# sum_n = ap.sum_of_n_terms(a1, d, n)
#
# print(f"{n}-й член прогресії: {nth}")
# print(f"Сума перших {n} членів прогресії: {sum_n}")
