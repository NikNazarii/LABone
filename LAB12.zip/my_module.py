import math
import random
import numpy as np

# def calculate_triangle(a, b):
#     c = math.sqrt(a**2 + b**2)
#     S = a * b
#     print("Гіпотенуза =", c)
#     print("Площа =", S)
#
# def generate_random_matrix(rows=3, cols=2):
#     matrix = np.random.randint(0, 10, (rows, cols))
#     return matrix
#
# def generate_random_string(length):
#     letters = 'abcdefghijklmnopqrstuvwxyz'
#     return ''.join(random.choice(letters) for _ in range(length))

# 3. Написати модуль з такими функціями: 1) для визначення N-го члена
# арифметичної прогресії; 2) для визначення суми N членів арифметичної
# прогресії. Підключити модуль до основної програми і виконати відповідні
# обчислення.

# def nth_term(a1, d, n):
#     return a1 + (n - 1) * d
#
# def sum_of_n_terms(a1, d, n):
#     return (n / 2) * (2 * a1 + (n - 1) * d)
